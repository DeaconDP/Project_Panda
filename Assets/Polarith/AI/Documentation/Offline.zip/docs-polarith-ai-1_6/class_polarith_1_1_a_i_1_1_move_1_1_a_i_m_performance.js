var class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance =
[
    [ "Performance", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance_a75464c3c7d458dd1e27fac536c0b7086.html#a75464c3c7d458dd1e27fac536c0b7086", null ],
    [ "Threads", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance_a29830ef3d09fb2fa559aac06e303389e.html#a29830ef3d09fb2fa559aac06e303389e", null ],
    [ "UpdateFrequency", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance_aa6c298786ca3622cfa67003ec210c281.html#aa6c298786ca3622cfa67003ec210c281", null ],
    [ "TargetFps", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance_a6d0beff5455f2161244619523a308d5d.html#a6d0beff5455f2161244619523a308d5d", null ],
    [ "instancesCount", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance.html#a5e77cd34360c772e1263646afc2cbc49", null ],
    [ "InstancesCount", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_performance.html#ae7c4dac66b059e2950aa1b7b8dd9af8f", null ]
];