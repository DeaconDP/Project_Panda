var class_polarith_1_1_a_i_1_1_criteria_1_1_receptor =
[
    [ "NeighbourIDs", "class_polarith_1_1_a_i_1_1_criteria_1_1_receptor_a13abfb9bea7b30375ebb452de0723fe1.html#a13abfb9bea7b30375ebb452de0723fe1", null ],
    [ "ID", "class_polarith_1_1_a_i_1_1_criteria_1_1_receptor_af180e926633cde08a05ccbc3af397ee4.html#af180e926633cde08a05ccbc3af397ee4", null ],
    [ "Structure", "class_polarith_1_1_a_i_1_1_criteria_1_1_receptor_a900005d80c44e25edff818234f5cadb6.html#a900005d80c44e25edff818234f5cadb6", null ]
];